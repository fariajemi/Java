import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class Item {

	private JFrame frame;
	private JButton btnDeleteItem;
	private JButton btnAddItem;
	private JLabel lblItemManagementSystem;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Item window = new Item();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Item() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		frame.setBounds(100, 100, 280, 280);
		frame.setTitle("Item");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			@SuppressWarnings("static-access")
			public void actionPerformed(ActionEvent arg0) {
				Main M=new Main();
				M.main(null);
				frame.dispose();
			}
		});
		btnBack.setBounds(23, 168, 117, 25);
		frame.getContentPane().add(btnBack);
		
		
		
		
		
		/**
		 * Delete Item Button.
		 */
		btnDeleteItem = new JButton("Delete Item");
		btnDeleteItem.addActionListener(new ActionListener() {
			@SuppressWarnings("static-access")
			public void actionPerformed(ActionEvent e) {
				DelateItem D=new DelateItem();
				D.main(null);
				frame.dispose();
			}
		});
		btnDeleteItem.setBounds(65, 70, 150, 25);
		frame.getContentPane().add(btnDeleteItem);
		
		
		
		
		
		
		
		/**
		 * Add Item Button.
		 */
		btnAddItem = new JButton("Add Item");
		btnAddItem.addActionListener(new ActionListener() {
			@SuppressWarnings("static-access")
			public void actionPerformed(ActionEvent e) {
				AddItem A=new AddItem();
				A.main(null);
				frame.dispose();
			}
		});
		btnAddItem.setBounds(65, 115, 150, 25);
		frame.getContentPane().add(btnAddItem);
		
		
		
		
		
		lblItemManagementSystem = new JLabel("Item Management System");
		lblItemManagementSystem.setForeground(Color.WHITE);
		lblItemManagementSystem.setBounds(65, 29, 198, 15);
		frame.getContentPane().add(lblItemManagementSystem);
	}
}
