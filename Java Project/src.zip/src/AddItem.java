import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class AddItem {

	private JFrame frame;
	private JTextField Itname;
	private JTextField Itprice;
	public Scanner scan;
	private String name;
	public String fullnames;
	public JTextArea textArea;
	public int num;
	private String price;
	public JScrollPane scrollPane;
	public String Item,prc;
	public int t=0,i;
	public ArrayList<String> arr;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddItem window = new AddItem();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application, Open file and read file.
	 */
	public AddItem() {
		initialize();
		openFile();
		readFile();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() 
	{
		
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		frame.setBounds(100, 100, 430, 460);
		frame.setTitle("Add Item");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblAddItem = new JLabel("Add Item");
		lblAddItem.setForeground(Color.WHITE);
		lblAddItem.setBounds(150, 15, 100, 15);
		frame.getContentPane().add(lblAddItem);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(43, 70, 340, 167);
		frame.getContentPane().add(scrollPane);
		
		textArea = new JTextArea();
		textArea.setEditable(false);
		scrollPane.setViewportView(textArea);
		
		JLabel lblEnterItemName = new JLabel("Enter Item Name :");
		lblEnterItemName.setForeground(Color.WHITE);
		lblEnterItemName.setBounds(45, 255, 139, 15);
		frame.getContentPane().add(lblEnterItemName);
		
		JLabel lblNewLabel = new JLabel("  ID  \t                    Name                                            \tPrice");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(45, 40, 345, 30);
		frame.getContentPane().add(lblNewLabel);
		
		
		
		
		
		
		/**
		 * Back Button.
		 */
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			@SuppressWarnings("static-access")
			public void actionPerformed(ActionEvent arg0) {
				
				Item IT=new Item();
				IT.main(null);
				frame.dispose();
			}
		});
		btnBack.setBounds(29, 370, 117, 25);
		frame.getContentPane().add(btnBack);
		
		
		
		
		
		
		
		
		JLabel lblEnterPrice = new JLabel("Enter price :");
		lblEnterPrice.setForeground(Color.WHITE);
		lblEnterPrice.setBounds(45, 286, 139, 15);
		frame.getContentPane().add(lblEnterPrice);
		
		Itname = new JTextField();
		Itname.setBounds(240, 255, 114, 19);
		frame.getContentPane().add(Itname);
		Itname.setColumns(10);
		
		Itprice = new JTextField();
		Itprice.setColumns(10);
		Itprice.setBounds(240, 286, 114, 19);
		frame.getContentPane().add(Itprice);
		
		
		
		
		
		/**
		 * Add Button.
		 */
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				t=0;
				is_empty();
				if(t==0)
				{
					is_intID();
					if(t==0)
					{
						Item=Itname.getText().toString();
						prc=Itprice.getText().toString();
						openFile();
						Add();
					}
				}
			}
		    
		});
		btnAdd.setBounds(133, 320, 117, 25);
		frame.getContentPane().add(btnAdd);
	}
	
	
	
	
	
	
	/**
	 * Open File Method.
	 */
	private void openFile()
    {
        try
        {
            scan = new Scanner(new File("item.txt"));
            System.out.println("File found!");
        }
        
        catch(Exception e)
        {
            System.out.println("File not found");
        }
    }
	
	
	
	
	
	/**
	 * Read File Method.
	 */
	private void readFile()
    {
		num =1;
        try
        {
	       while(scan.hasNextLine())
		        {
		            name = scan.nextLine();
		            price = scan.nextLine();
					textArea.append(num+"\t"+name + " \t\t" + price + " \t\n");
		            num++;
		        }
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
	
	
	
	
	/**
	 * Empty Checker.
	 */
	public void is_empty()
	{
		if(Itname.getText().isEmpty() && Itprice.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(scrollPane, "Enter Item Name and Price.");
			t=1;
		}
	    else if(Itname.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(scrollPane, "Enter Item Name.");
			t=1;
		}
		else if(Itprice.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(scrollPane, "Enter Item Price.");
			t=1;
		}
	}
	
	
	
	
	/**
	 * Is Value Integet.
	 */
	public void is_intID()
	{
		try 
		{
		     Integer.parseInt(Itprice.getText());
		     System.out.println("An integer");
		}
		catch (NumberFormatException e) 
		{
			JOptionPane.showMessageDialog(scrollPane, "Enter an Integer number in price.");
			t=1;
		}
	}
	
	
	
	
	
	/**
	 * Add Item name and Price.
	 */
	private void Add()
    {
		File file = new File("item.txt");
		arr=new ArrayList<String>();
        try{
		       while(scan.hasNextLine())
			        {
			    	   name = scan.nextLine();
			           price = scan.nextLine();
				    		   arr.add(name);
					           arr.add(price);
			        }
		       arr.add(Item);
	           arr.add(prc);
		       
		       PrintWriter writer = new PrintWriter(file);
		       writer.print("");
		       
		       for(int k=0;k<arr.size();k++)
			       {
			    	   writer.println(arr.get(k).toString());
			       }
		       writer.close();
		       arr.clear();
		       JOptionPane.showMessageDialog(scrollPane, "Add Successfully.");
		       Itname.setText(null);
		       Itprice.setText(null);
            }
        catch(Exception e)
	        {
	            System.out.println(e);
	        }    
    }	
}
