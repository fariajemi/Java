import java.awt.EventQueue;
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DelateItem {

	private JFrame frame;
	public Scanner scan;
	private String name;
	public String fullnames;
	public int num;
	public int i,q,amount=0,t=0;
	private String price;
	public JTextArea textArea;
	private JTextField del;
	public ArrayList<String> arr;
	public int found=0;
	JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DelateItem window = new DelateItem();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	
	
	
	/**
	 * Create the application,Open and read file.
	 */
	public DelateItem() {
		initialize();
		openFile();
		readFile();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		frame.setBounds(100, 100, 430, 450);
		frame.setTitle("Delete Item");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
	
		scrollPane = new JScrollPane();
		scrollPane.setBounds(43, 70, 340, 167);
		frame.getContentPane().add(scrollPane);
		
		textArea = new JTextArea();
		textArea.setEditable(false);
		scrollPane.setViewportView(textArea);
		
		JLabel lblDeleteItem = new JLabel("Delete Item");
		lblDeleteItem.setForeground(Color.WHITE);
		lblDeleteItem.setBounds(160, 20, 128, 19);
		frame.getContentPane().add(lblDeleteItem);
		
		
		JLabel lblIdNamePrice = new JLabel("  ID  \t                    Name                                            \tPrice");
	    lblIdNamePrice.setForeground(Color.WHITE);
	    lblIdNamePrice.setBounds(45, 40, 345, 30);
	    frame.getContentPane().add(lblIdNamePrice);
	    
	    JLabel lblWhichIdItem = new JLabel("Enter delete Item Id :");
	    lblWhichIdItem.setForeground(Color.WHITE);
	    lblWhichIdItem.setBounds(42, 265, 219, 25);
	    frame.getContentPane().add(lblWhichIdItem);
	    
	    del = new JTextField();
	    del.setColumns(10);
	    del.setBounds(269, 265, 114, 25);
	    frame.getContentPane().add(del);
	    
	    
	    
	    
	    /**
		 * Back Button.
		 */
	    
	    JButton btnBack = new JButton("Back");
	    btnBack.addActionListener(new ActionListener() {
	    	@SuppressWarnings("static-access")
			public void actionPerformed(ActionEvent arg0) {
	    		Item I=new Item();
	    		I.main(null);
	    		frame.dispose();
	    	}
	    });
	    btnBack.setBounds(43, 355, 117, 25);
	    frame.getContentPane().add(btnBack);
	    
	    
	    
	    
	    
	    
	    
	    /**
		 * Delete Button.
		 */
	    JButton btnDelete = new JButton("Delete");
	    btnDelete.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	    		t=0;
	    		found=0;
	    		is_empty();
	    		if(t==0)
	    		{
	    			is_intID();
	    		   if(t==0)
		    		{
	    			   i=Integer.parseInt(del.getText());
		    		   openFile();
		    		   Find(i);
		    		   if(found==0)
		    			   JOptionPane.showMessageDialog(scrollPane, "Id not found.");
		    		}
	    		}
	    		
	    		del.setText("");
	    	}
	    });
	    btnDelete.setBounds(171, 310, 117, 25);
	    frame.getContentPane().add(btnDelete);
	}
	
	
	
	
	
	
	
	
	
	/**
	 * Open File Method.
	 */
	private void openFile()
    {
        try
        {
            scan = new Scanner(new File("item.txt"));
            System.out.println("File found!");
        }
        
        catch(Exception e)
        {
            System.out.println("File not found");
        }
    }
	
	
	
	
	
	/**
	 * Read File Method.
	 */
	private void readFile()
    {
		num =1;
        try
        {
	       while(scan.hasNextLine())
	        {
	            name = scan.nextLine();
	            price = scan.nextLine();
				textArea.append(num+"\t"+name + " \t\t" + price + " \t\n");
	            num++;
	        }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
	
	
	
	
	
	
	/**
	 * Find Item.
	 */
	private void Find(int n)
    {
		File file = new File("item.txt");
		arr=new ArrayList<String>();
		num =1;
		try{
		       while(scan.hasNextLine())
			        {
			    	   name = scan.nextLine();
			           price = scan.nextLine();
			    	   if(num==n) 
			    		   { 
			    		       found=1;
			    		       del.setText("");
			    		       JOptionPane.showMessageDialog(scrollPane, "Delete Successfully.");
			    		       num++;
			    		       continue;
			    		   }
			    	   else 
				           {
				    		   arr.add(name);
					           arr.add(price);
				           }
			            num++;
			        }
		       
		       PrintWriter writer = new PrintWriter(file);
		       writer.print("");
		       
		       for(int k=0;k<arr.size();k++)
			       {
			    	   writer.println(arr.get(k).toString());
			       }
		       writer.close();
		       arr.clear();
		       frame.revalidate();
			   frame.repaint();
           }
        catch(Exception e)
			{
	            System.out.println(e);
	        }    
    }
	
	
	
	
	
	/**
	 * Is value Integet.
	 */
	public void is_intID()
	{
		try {
		     Integer.parseInt(del.getText());
		     System.out.println("An integer");
		}
		catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(scrollPane, "Enter Id number.");
			t=1;
		}
	}
	
	
	
	
	/**
	 * Empty checker.
	 */
	public void is_empty()
	{
		if(del.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(scrollPane, "Enter Id Number.");
			t=1;
		}
	}
}
