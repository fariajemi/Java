import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login {

	private JFrame frame;
	private JTextField InUSER;
	private JPasswordField passwordField;
	public String pass="admin";
	public String Userid;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		frame.setBounds(100, 100, 280, 250);
		frame.setTitle("Login Screen");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel Username = new JLabel("Username : ");
		Username.setForeground(Color.WHITE);
		Username.setBackground(Color.DARK_GRAY);
		Username.setBounds(15, 30, 100, 15);
		frame.getContentPane().add(Username);
		
		JLabel password = new JLabel("Password : ");
		password.setForeground(Color.WHITE);
		password.setBackground(Color.DARK_GRAY);
		password.setBounds(15, 60, 100, 15);
		frame.getContentPane().add(password);
		
		InUSER = new JTextField();
		InUSER.setBounds(133, 30, 114, 19);
		frame.getContentPane().add(InUSER);
		InUSER.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setEchoChar('*');
		passwordField.setBounds(133, 60, 114, 19);
		frame.getContentPane().add(passwordField);
		
		
		
		
		
		
		
		/**
		 * Login Button.
		 */
		JButton Login = new JButton("Login");
		Login.addActionListener(new ActionListener() {
			@SuppressWarnings("static-access")
			public void actionPerformed(ActionEvent arg0) {
				Userid=InUSER.getText();
				System.out.println(Userid);
				System.out.println(pass);
				if(Userid.equals("admin") && pass.equals(new String(passwordField.getPassword())))
				{
					Item I=new Item();
					I.main(null);
					frame.dispose();
				}
				else
				{
					JOptionPane.showMessageDialog(frame,"Invalid Username or Password.","Inane warning",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		Login.setBounds(70, 100, 117, 25);
		frame.getContentPane().add(Login);
		
		
		
		
		
		
		
		
		
		/**
		 * Back Button.
		 */
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			@SuppressWarnings("static-access")
			public void actionPerformed(ActionEvent e) {
				Main M=new Main();
				M.main(null);
				frame.dispose();
			}
		});
		btnBack.setBounds(12, 169, 117, 25);
		frame.getContentPane().add(btnBack);
		
	}
}
