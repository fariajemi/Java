import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Main {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
	}

	
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setFont(null);
		frame.setBackground(new Color(240, 240, 240));
		frame.setTitle("Restaurant");
		frame.getContentPane().setFont(new Font("Arial", Font.PLAIN, 11));
		frame.getContentPane().setBackground(new Color(64, 64, 64));
		frame.getContentPane().setLayout(null);
		frame.setBounds(100, 100, 360, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel Name = new JLabel("Restaurant Management System");
		Name.setBounds(82, 36, 260, 22);
		Name.setForeground(Color.WHITE);
		Name.setBackground(Color.WHITE);
		frame.getContentPane().add(Name);
		
		
		
		
		
		
		
		
		/**
		 *Item Management Button.
		 */
		JButton item = new JButton("Item Management");
		item.addActionListener(new ActionListener() {
			@SuppressWarnings("static-access")
			public void actionPerformed(ActionEvent e) {
				Login L=new Login();
				L.main(null);
				frame.dispose();
			}
		});
		item.setBounds(78, 80, 200, 25);
		frame.getContentPane().add(item);
		
		
		
		
		
		
		
		
		
		/**
		 * Order Management Button.
		 */
		JButton order = new JButton("Order Management");
		order.addActionListener(new ActionListener() {
			@SuppressWarnings("static-access")
			public void actionPerformed(ActionEvent e) {
				Order O=new Order();
				O.main(null);
				frame.dispose();
			}
		});
		order.setBounds(78, 120, 200, 25);
		frame.getContentPane().add(order);
		
		
		
		
		
		
		
		/**
		 * Exit Button.
		 */
		JButton Exit = new JButton("Exit");
		Exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		Exit.setBounds(118, 165, 117, 25);
		frame.getContentPane().add(Exit);
	}
}
