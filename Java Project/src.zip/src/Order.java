import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Order {

	public int i,q,amount=0,t=0,found=0;
	private JFrame frame;
	public Scanner scan;
	private String name;
	public String fullnames;
	public int num;
    private String price;
    public JTextArea textArea;
    private JTextField Id;
    private JTextField qan;
    JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Order window = new Order();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Order() {
		initialize();
		openFile();
		readFile();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		frame.setBounds(100, 100, 430, 500);
		frame.setTitle("Order");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
		
		
		
		/**
		 * Back Button.
		 */
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			@SuppressWarnings("static-access")
			public void actionPerformed(ActionEvent arg0) {
				Main M=new Main();
				M.main(null);
				frame.dispose();
			}
		});
		btnBack.setBounds(12, 412, 117, 25);
		frame.getContentPane().add(btnBack);
		
		
		
		
		
		
		
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(43, 90, 340, 167);
		frame.getContentPane().add(scrollPane);
		
	    textArea = new JTextArea();
	    textArea.setEditable(false);
	    scrollPane.setViewportView(textArea);
	    
	    JLabel lblEnter = new JLabel("Which ID Item you want ?");
	    lblEnter.setForeground(Color.WHITE);
	    lblEnter.setBounds(45, 279, 199, 25);
	    frame.getContentPane().add(lblEnter);
	    
	    Id = new JTextField();
	    Id.setBounds(270, 282, 114, 25);
	    frame.getContentPane().add(Id);
	    Id.setColumns(10);
	    
	    JLabel lblEnterQuantity = new JLabel("Enter Quantity :");
	    lblEnterQuantity.setForeground(Color.WHITE);
	    lblEnterQuantity.setBounds(45, 315, 199, 25);
	    frame.getContentPane().add(lblEnterQuantity);
	    
	    qan = new JTextField();
	    qan.setColumns(10);
	    qan.setBounds(270, 315, 114, 25);
	    frame.getContentPane().add(qan);
	    
	    
	    
	    
	    
	    /**
		 * New Item Button.
		 */
	    JButton btnA = new JButton("New Item");
	    btnA.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	    		t=0;
	    		found=0;
	    		is_empty();
		    	if(t==0)
		    	   {
		    		   is_intID();
		    		   is_intQAN();	
		    		   if(t==0)
			    		{
		    			    i=Integer.parseInt(Id.getText());
				    		q=Integer.parseInt(qan.getText());
				    		openFile();
				    		Find(i,q);
				    		Id.setText("");
				    		qan.setText("");
			    		}
			    	}
	    	}
	    });
	    btnA.setBounds(250, 360, 117, 25);
	    frame.getContentPane().add(btnA);
	    
	    
	    
	    
	    
	    
	    
	    /**
		 * Order Button.
		 */
	    JButton btnOrder = new JButton("Order");
	    btnOrder.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		t=0;
	    		found=0;
	    		is_empty();
		    	if(t==0)
		    	   {
		    		   is_intID();
		    		   is_intQAN();	
		    		   if(t==0)
			    		{
		    			    i=Integer.parseInt(Id.getText());
				    		q=Integer.parseInt(qan.getText());
				    		openFile();
				    		Find(i,q);
				    		JOptionPane.showMessageDialog(scrollPane, "Your Bill is : "+amount+" TK");
				    		Id.setText("");
				    		qan.setText("");
				    		amount=0;
			    		}
			    	}
	    	}
	    });
	    btnOrder.setBounds(70, 360, 117, 25);
	    frame.getContentPane().add(btnOrder);
	    
	    
	    
	    
	    
	    
	    JLabel lblIdNamePrice = new JLabel("  ID  \t                    Name                                            \tPrice");
	    lblIdNamePrice.setForeground(Color.WHITE);
	    lblIdNamePrice.setBounds(45, 60, 345, 30);
	    frame.getContentPane().add(lblIdNamePrice);
	    
	    JLabel lblOrderManagementSystem = new JLabel("Order Management System");
	    lblOrderManagementSystem.setForeground(Color.WHITE);
	    lblOrderManagementSystem.setBounds(112, 10, 228, 19);
	    frame.getContentPane().add(lblOrderManagementSystem);
		
	}
	
	
	
	
	
	
	/**
	 * Open File Method.
	 */
	private void openFile()
    {
        try
        {
            scan = new Scanner(new File("item.txt"));
            System.out.println("File found!");
        }
        
        catch(Exception e)
        {
            System.out.println("File not found");
      
        }
    }
	
	
	
	
	
	
	/**
	 * Read File Method.
	 */
	private void readFile()
    {
		num =1;
        try{
       while(scan.hasNextLine())
        {
            name = scan.nextLine();
            price = scan.nextLine();
			textArea.append(num+"\t"+name + " \t\t" + price + " \t\n");
            num++;
        }
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
	
	
	
	
	
	
	
	/**
	 * Find Item and Calculation Bill.
	 */
	private void Find(int n,int qn)
    {
		num =1;
		int pr;
	    try{
		       while(scan.hasNextLine())
		        {
		            name = scan.nextLine();
		            price = scan.nextLine();
		            //System.out.println(name+"  "+price);
		            if(num==n)
					{
		                pr = Integer.parseInt(price);
		                amount+=pr*qn;
		                System.out.println(name+"  "+pr);
		                found=1;
		            	break;
		            }
		            num++;
		        }
		       if(found==0)
		    	   JOptionPane.showMessageDialog(scrollPane, "Id not found.");
	        }
	        catch(Exception e)
	        {
	            System.out.println(e);
	        }   
    }
	
	
	
	
	
	
	
	/**
	 * Empty Checker.
	 */
	public void is_empty()
	{
		if(Id.getText().isEmpty() && qan.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(scrollPane, "Enter Item Id and Quantity.");
			t=1;
		}
	    else if(Id.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(scrollPane, "Enter Item Id.");
			t=1;
		}
		else if(qan.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(scrollPane, "Enter Quantity.");
			t=1;
		}
	}
	
	
	
	
	
	
	
	/**
	 * Is ID's value Integer.
	 */
	public void is_intID()
	{
		try {
		     Integer.parseInt(Id.getText());
		     System.out.println("An integer");
		}
		catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(scrollPane, "Enter an Id number.");
			Id.setText(null);
			t=1;
		}
	}
	
	
	
	
	
	
	/**
	 * Is Quantity's value Integer.
	 */
	public void is_intQAN()
	{
		try {
		     Integer.parseInt(qan.getText());
		     System.out.println("An integer");
		}
		catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(scrollPane, "Enter Quantity. ");
			qan.setText(null);
			t=1;
		}
	}
}
